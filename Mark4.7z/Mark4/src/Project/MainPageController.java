package Project;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;

public class MainPageController implements Initializable {
	
	static ArrayList<String> menu = new ArrayList<>();
	static ArrayList<Integer> quant = new ArrayList<>();
	static ArrayList<Double> price = new ArrayList<>();
	
 	
    @FXML private TableView<Burger> tableView1;
    @FXML private TableColumn<Burger, String> OrderItemColumn1;
    @FXML private TableColumn<Burger, Integer> QuantityColumn1;
    
    @FXML private TableView<Drink> tableView2;
    @FXML private TableColumn<Drink, String> OrderItemColumn2;
    @FXML private TableColumn<Drink, Integer> QuantityColumn2;
    
    @FXML private RadioButton CB;
    @FXML private RadioButton BB;
    @FXML private RadioButton DCB;
    @FXML private RadioButton DBB;
    @FXML private RadioButton BM;
    @FXML private RadioButton CB1;
    @FXML private RadioButton BB1;
    @FXML private RadioButton DCB1;
    @FXML private RadioButton DBB1;
    @FXML private RadioButton BM1;
    @FXML private RadioButton CB11;
    @FXML private RadioButton BB11;
    @FXML private RadioButton DCB11;
    
    @FXML private RadioButton coke;
    @FXML private RadioButton fruit_punch;
    @FXML private RadioButton mojitos;
    @FXML private RadioButton lemonade;
    @FXML private RadioButton ice_tea;
    @FXML private RadioButton coke1;
    @FXML private RadioButton fruit_punch1;
    @FXML private RadioButton mojitos1;
    @FXML private RadioButton lemonade1;
    @FXML private RadioButton ice_tea1;
    
    @FXML private Button AddBurger;
    @FXML private Button AddDrink;
    @FXML private Button DeleteBtn;
    @FXML private Button ProceedBtn;
    
    @FXML private TextField quantityBurger;
    @FXML private TextField quantityBurger1;
    @FXML private TextField quantityBurger11;
    @FXML private TextField quantityDrink;
    @FXML private TextField quantityDrink1;
    
    @FXML private Label quantityLabel1;
    @FXML private Label quantityLabel2;
    
    
	
    @Override
    public void initialize(URL url, ResourceBundle rb) {
		
		OrderItemColumn1.setCellValueFactory(new PropertyValueFactory<Burger, String>("menuBurger"));
		QuantityColumn1.setCellValueFactory(new PropertyValueFactory<Burger, Integer>("quantity"));
		
		OrderItemColumn1.setCellFactory(TextFieldTableCell.forTableColumn());
		
		tableView1.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		
		OrderItemColumn2.setCellValueFactory(new PropertyValueFactory<Drink, String>("menuDrink"));
		QuantityColumn2.setCellValueFactory(new PropertyValueFactory<Drink, Integer>("quantity"));
		
		OrderItemColumn2.setCellFactory(TextFieldTableCell.forTableColumn());
		
		tableView2.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
	}
    
    @FXML
    public void newBurgerButtonPushed()
    {
    	
    	
    	if(CB.isSelected()){
    		 Integer value = Integer.valueOf(quantityBurger.getText());
    		 
    	     Burger newBurger = new Burger("Spring Roll" ,value);
    	     tableView1.getItems().add(newBurger);
    	     
    	     menu.add("Spring Roll");
    	     quant.add(value);
    	     price.add(value*8.00);
    	     
    	     Menu.calculateOrder(8.00*value);
    	}
    	
    	else if(BB.isSelected()){
   		 Integer value = Integer.valueOf(quantityBurger.getText());
   		 
   	     Burger newBurger = new Burger("Gobi Munchurian" ,value);
   	     tableView1.getItems().add(newBurger);
   	     
	     menu.add("Gobi Munchurian");
	     quant.add(value);
	     price.add(value*7.00);
	     
	     Menu.calculateOrder(7.00*value);
   	}
    	
    	else if(DCB.isSelected()){
   		 Integer value = Integer.valueOf(quantityBurger.getText());
   		 
   	     Burger newBurger = new Burger("Masala Papad" ,value);
   	     tableView1.getItems().add(newBurger);
   	     
	     menu.add("Masala Papad");
	     quant.add(value);
	     price.add(value*14.00);
	     
	     Menu.calculateOrder(14.00*value);
   	}
    	
    	else if(DBB.isSelected()){
   		 Integer value = Integer.valueOf(quantityBurger.getText());
   		 
   	     Burger newBurger = new Burger("Chicken Lollipop" ,value);
   	     tableView1.getItems().add(newBurger);
   	     
	     menu.add("Chicken Lollipop");
	     quant.add(value);
	     price.add(value*13.00);
	     
	     Menu.calculateOrder(13.00*value);
   	}
    	
    	else if(BM.isSelected()){
   		 Integer value = Integer.valueOf(quantityBurger.getText());
   		 
   	     Burger newBurger = new Burger("Meat Balls" ,value);
   	     tableView1.getItems().add(newBurger);
   	     
	     menu.add("Meat Balls");
	     quant.add(value);
	     price.add(value*15.00);
	     
	     Menu.calculateOrder(15.00*value);
   	}
}
    @FXML
    public void newBurgerButtonPushed1()
    {
    	
    	
    	if(CB1.isSelected()){
    		 Integer value = Integer.valueOf(quantityBurger1.getText());
    		 
    	     Burger newBurger = new Burger("Panner Kadai" ,value);
    	     tableView1.getItems().add(newBurger);
    	     
    	     menu.add("Panner Kadai");
    	     quant.add(value);
    	     price.add(value*8.00);
    	     
    	     Menu.calculateOrder(8.00*value);
    	}
    	
    	else if(BB1.isSelected()){
   		 Integer value = Integer.valueOf(quantityBurger1.getText());
   		 
   	     Burger newBurger = new Burger("Veg Biriyani" ,value);
   	     tableView1.getItems().add(newBurger);
   	     
	     menu.add("Veg Biriyani");
	     quant.add(value);
	     price.add(value*7.00);
	     
	     Menu.calculateOrder(7.00*value);
   	}
    	
    	else if(DCB1.isSelected()){
   		 Integer value = Integer.valueOf(quantityBurger1.getText());
   		 
   	     Burger newBurger = new Burger("Schezwan Noodles" ,value);
   	     tableView1.getItems().add(newBurger);
   	     
	     menu.add("Schezwan Noodles");
	     quant.add(value);
	     price.add(value*14.00);
	     
	     Menu.calculateOrder(14.00*value);
   	}
    	
    	else if(DBB1.isSelected()){
   		 Integer value = Integer.valueOf(quantityBurger1.getText());
   		 
   	     Burger newBurger = new Burger("Chicken Biriyani" ,value);
   	     tableView1.getItems().add(newBurger);
   	     
	     menu.add("Chicken Biriyani");
	     quant.add(value);
	     price.add(value*13.00);
	     
	     Menu.calculateOrder(13.00*value);
   	}
    	
    	else if(BM1.isSelected()){
   		 Integer value = Integer.valueOf(quantityBurger1.getText());
   		 
   	     Burger newBurger = new Burger("Chicken Shawarma" ,value);
   	     tableView1.getItems().add(newBurger);
   	     
	     menu.add("Chicken Shawarma");
	     quant.add(value);
	     price.add(value*15.00);
	     
	     Menu.calculateOrder(15.00*value);
   	}
}
    @FXML
    public void newBurgerButtonPushed2()
    {
    	
    	
    	if(CB11.isSelected()){
    		 Integer value = Integer.valueOf(quantityBurger11.getText());
    		 
    	     Burger newBurger = new Burger("Ice Cream" ,value);
    	     tableView1.getItems().add(newBurger);
    	     
    	     menu.add("Ice Cream");
    	     quant.add(value);
    	     price.add(value*8.00);
    	     
    	     Menu.calculateOrder(8.00*value);
    	}
    	
    	else if(BB11.isSelected()){
   		 Integer value = Integer.valueOf(quantityBurger11.getText());
   		 
   	     Burger newBurger = new Burger("Ice Cream and Gulab Jamun" ,value);
   	     tableView1.getItems().add(newBurger);
   	     
	     menu.add("Ice Cream and Gulab Jamun");
	     quant.add(value);
	     price.add(value*7.00);
	     
	     Menu.calculateOrder(7.00*value);
   	}
    	
    	else if(DCB11.isSelected()){
   		 Integer value = Integer.valueOf(quantityBurger11.getText());
   		 
   	     Burger newBurger = new Burger("Ice Cream and Carrot Halwa" ,value);
   	     tableView1.getItems().add(newBurger);
   	     
	     menu.add("Ice Cream and Carrot Halwa");
	     quant.add(value);
	     price.add(value*14.00);
	     
	     Menu.calculateOrder(14.00*value);
   	}    	   	
}
    @FXML
    public void newDrinkButtonPushed()
    {
    	if(ice_tea.isSelected()){
    		 Integer value = Integer.valueOf(quantityDrink.getText());
    		 
    	     Drink newDrink = new Drink("Ice Tea" ,value);
    	     tableView2.getItems().add(newDrink);
    	     
    	     menu.add("Ice Tea");
    	     quant.add(value);
    	     price.add(value*2.00);
    	     
    	     Menu.calculateOrder(2.00*value);
    	}
    	
    	else if(lemonade.isSelected()){
   		 Integer value = Integer.valueOf(quantityDrink.getText());
   		 
   	     Drink newDrink = new Drink("Frosty Ice Cream Soda" ,value);
   	     tableView2.getItems().add(newDrink);
   	     
	     menu.add("Frosty Ice Cream Soda");
	     quant.add(value);
	     price.add(value*3.00);
	     
	     Menu.calculateOrder(3.00*value);
   	}
    	else if(mojitos.isSelected()){
   		 Integer value = Integer.valueOf(quantityDrink.getText());
   		 
   	     Drink newDrink = new Drink("JELL-O Spritzers" ,value);
   	     tableView2.getItems().add(newDrink);
   	     
	     menu.add("JELL-O Spritzers");
	     quant.add(value);
	     price.add(value*1.50);
	     
	     Menu.calculateOrder(1.50*value);
   	}
    	else if(fruit_punch.isSelected()){
   		 Integer value = Integer.valueOf(quantityDrink.getText());
   		 
   	     Drink newDrink = new Drink("Kool-Aid Fruit Punch" ,value);
   	     tableView2.getItems().add(newDrink);
   	     
	     menu.add("Kool-Aid Fruit Punch");
	     quant.add(value);
	     price.add(value*1.50);
	     
	     Menu.calculateOrder(1.50*value);
   	}
    	else if(coke.isSelected()){
   		 Integer value= Integer.valueOf(quantityDrink.getText());
   		 
   	     Drink newDrink = new Drink("Oreo Shake" ,value);
   	     tableView2.getItems().add(newDrink);
   	     
	     menu.add("Oreo Shake");
	     quant.add(value);
	     price.add(value*1.00);
	     
	     Menu.calculateOrder(1.00*value);
   	}
}
    @FXML
    public void newDrinkButtonPushed1()
    {
    	if(coke1.isSelected()){
    		 Integer value = Integer.valueOf(quantityDrink1.getText());
    		 
    	     Drink newDrink = new Drink("Hot Chocolate" ,value);
    	     tableView2.getItems().add(newDrink);
    	     
    	     menu.add("Hot Chocolate");
    	     quant.add(value);
    	     price.add(value*2.00);
    	     
    	     Menu.calculateOrder(2.00*value);
    	}
    	
    	else if(fruit_punch1.isSelected()){
   		 Integer value = Integer.valueOf(quantityDrink1.getText());
   		 
   	     Drink newDrink = new Drink("Herbal Tea" ,value);
   	     tableView2.getItems().add(newDrink);
   	     
	     menu.add("Herbal Tea");
	     quant.add(value);
	     price.add(value*3.00);
	     
	     Menu.calculateOrder(3.00*value);
   	}
    	else if(mojitos1.isSelected()){
   		 Integer value = Integer.valueOf(quantityDrink1.getText());
   		 
   	     Drink newDrink = new Drink("Masala Tea" ,value);
   	     tableView2.getItems().add(newDrink);
   	     
	     menu.add("Masala Tea");
	     quant.add(value);
	     price.add(value*1.50);
	     
	     Menu.calculateOrder(1.50*value);
   	}
    	else if(lemonade1.isSelected()){
   		 Integer value = Integer.valueOf(quantityDrink1.getText());
   		 
   	     Drink newDrink = new Drink("Coffee" ,value);
   	     tableView2.getItems().add(newDrink);
   	     
	     menu.add("Coffee");
	     quant.add(value);
	     price.add(value*1.50);
	     
	     Menu.calculateOrder(1.50*value);
   	}
    	else if(ice_tea1.isSelected()){
   		 Integer value= Integer.valueOf(quantityDrink1.getText());
   		 
   	     Drink newDrink = new Drink("Tea" ,value);
   	     tableView2.getItems().add(newDrink);
   	     
	     menu.add("Tea");
	     quant.add(value);
	     price.add(value*1.00);
	     
	     Menu.calculateOrder(1.00*value);
   	}
}
    @FXML
	public void proceedBtn(ActionEvent event) throws IOException{
		Parent receiptPage = FXMLLoader.load(getClass().getResource("Receipt.fxml"));
		Scene receiptPageScene = new Scene(receiptPage);
		
		Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
		
		window.setScene(receiptPageScene);
		window.show();
	}
    @FXML
    public void deleteButtonPushed()
    {
        ObservableList<Burger> selectedRows1, allOrder1;
        allOrder1 = tableView1.getItems();
        selectedRows1 = tableView1.getSelectionModel().getSelectedItems();
        Burger bg = tableView1.getSelectionModel().getSelectedItem();
        int ij= tableView1.getSelectionModel().getSelectedIndex();
        //System.out.println("Selected in Eatery : "+ij);
       
        if(ij!=-1)
        {
        	int i= menu.indexOf(bg.toString1());
        	
        	menu.remove(i);
            quant.remove(i);
            Menu.total-=price.get(i);
            price.remove(i);
        }
        
        
       for (Burger burger: selectedRows1)
        {
            allOrder1.remove(burger);
            
        }
        
        ObservableList<Drink> selectedRows2, allOrder2;
        allOrder2 = tableView2.getItems();
        
        selectedRows2 = tableView2.getSelectionModel().getSelectedItems();
        Drink bg2 = tableView2.getSelectionModel().getSelectedItem();
        int j= tableView2.getSelectionModel().getSelectedIndex();
       // System.out.println("Selected in Drink : "+j);
        
        if(j!=-1)
        {
        	int k= menu.indexOf(bg2.toString1());
        	menu.remove(k);
        	quant.remove(k);
        	Menu.total-=price.get(k);
        	price.remove(k);
        	
        }
        for (Drink drink: selectedRows2)
        {
            allOrder2.remove(drink);
        }
        tableView1.getSelectionModel().clearSelection();
        tableView2.getSelectionModel().clearSelection();
        ReceiptPageController.count=0;
    }
    
    public static ArrayList<String> getMenu(){
    	return menu;
    }
    
    public static ArrayList<Integer> getQuant(){
    	return quant;
    }
    
    public static ArrayList<Double> getPrice(){
    	return price;
    }
}